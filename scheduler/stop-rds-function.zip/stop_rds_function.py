import boto3
import os
import logging
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    region_name = os.environ.get('REGION_NAME')
    if not region_name:
        return {"status": "failed", "message": "REGION_NAME not found"}
    
    rds = boto3.client('rds', region_name=region_name)
    db_instance_identifiers = os.environ.get('DB_INSTANCE_IDENTIFIERS', '').split(',')
    if not db_instance_identifiers:
        return {"status": "failed", "message": "No instance identifiers provided"}

    results = []
    for db_instance_id in db_instance_identifiers:
        try:
            response = rds.stop_db_instance(DBInstanceIdentifier=db_instance_id)
            results.append({
                "DBInstanceIdentifier": db_instance_id,
                "Status": response['DBInstance']['DBInstanceStatus']
            })
        except ClientError as e:
            if e.response['Error']['Code'] == 'InvalidDBInstanceState':
                # Fetch the current status of the DB instance
                current_status = rds.describe_db_instances(DBInstanceIdentifier=db_instance_id)['DBInstances'][0]['DBInstanceStatus']
                results.append({
                    "DBInstanceIdentifier": db_instance_id,
                    "Status": current_status,
                    "message": f"Cannot stop instance, current state is '{current_status}'"
                })
            else:
                results.append({"DBInstanceIdentifier": db_instance_id, "Status": "failed", "message": str(e)})
    
    return {"status": "success" if all(r['Status'] != 'failed' for r in results) else "failed", "instances": results}
