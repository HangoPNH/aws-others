import boto3
import os
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Start EC2 instances in the region specified by the Lambda environment variable.
    """
    # Get the region name from the environment variable
    region_name = os.environ.get('REGION_NAME')
    if not region_name:
        logger.error("REGION_NAME environment variable not set.")
        return {"status": "failed", "message": "REGION_NAME not found in environment variables"}
    
    # Initialize EC2 client with the region from the environment
    ec2 = boto3.client('ec2', region_name=region_name)
    
    # Get instance IDs from the event
    instance_ids = os.environ.get('INSTANCE_IDS', '').split(',')
    if not instance_ids:
        logger.error("No instance IDs provided.")
        return {"status": "failed", "message": "No instance IDs provided"}
    
    try:
        # Start instances
        response = ec2.start_instances(InstanceIds=instance_ids)
        started_instances = [
            {"InstanceId": inst['InstanceId'], "State": inst['CurrentState']['Name']}
            for inst in response['StartingInstances']
        ]
        logger.info(f"Started instances: {started_instances}")
        return {"status": "success", "instances": started_instances}
    except Exception as e:
        logger.error(f"Error starting instances: {e}")
        return {"status": "failed", "message": str(e)}
