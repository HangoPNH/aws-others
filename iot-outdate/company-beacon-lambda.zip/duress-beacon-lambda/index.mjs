"use strict";
import {
  SecretsManagerClient,
  GetSecretValueCommand
} from "@aws-sdk/client-secrets-manager";
import moment from "moment";
import pg from "pg";
const { Client } = pg;
async function getSecretManager(secretName, versionStage) {
  const secretManagerClient = new SecretsManagerClient({ region: process.env.REGION_AWS });
  try {
    const response = await secretManagerClient.send(new GetSecretValueCommand({
      SecretId: secretName,
      VersionStage: versionStage
    }));
    if (response && response.SecretString) {
      return JSON.parse(response.SecretString);
    }
    return null;
  } catch (error) {
    console.error("Error while getting secret manager: ", error);
    return null;
  }
}
let dbConnection = null;
async function connectToDatabase() {
  console.log("Starting connect to DB");
  if (!dbConnection) {
    const secretManager = await getSecretManager(process.env.SECRET_NAME, process.env.VERSION_STAGE);
    if (secretManager === null) {
      console.error("Could not retrieve the secret manager!");
      return;
    }
    dbConnection = new Client(
      {
        user: secretManager.DB_USERNAME,
        host: secretManager.DB_SSH_HOST,
        database: secretManager.DB_HOSTNAME,
        password: secretManager.DB_PASSWORD,
        port: secretManager.PORT
      }
    );
    try {
      await dbConnection.connect();
      console.log("Connect database successfully");
    } catch (error) {
      console.error("There was an error when connecting DB: ", error);
      if (dbConnection) {
        await dbConnection.end();
        dbConnection = null;
      }
    }
  }
}
const convertBase64ToHex = (base64) => {
  return Buffer.from(base64, "base64").toString("hex");
};
const convertHexToDecimal = (hex) => {
  return parseInt(hex, 16);
};
function formatString(str) {
  let pairs = [];
  for (let i = 0; i < str.length; i += 2) {
    pairs.push(str.substring(i, i + 2));
  }
  return pairs;
}
export const handler = async (event) => {
  async function updateData(data) {
    try {
      for (const [macAddress, batteryLevel] of data) {
        const secondFormatMacAddress = formatString(macAddress).join("-");
        const thirdFormatMacAddress = formatString(macAddress).join(":");
        const res = await dbConnection.query(
          "SELECT 1 FROM duress_internal_tracking_beacons WHERE mac_address IN ($1, $2, $3)",
          [macAddress, secondFormatMacAddress, thirdFormatMacAddress]
        );
        if (res.rows.length > 0) {
          const timestamp = moment().utcOffset(0).format("YYYY-MM-DD HH:mm:ss.SSSZ");
          await dbConnection.query(
            "UPDATE duress_internal_tracking_beacons SET battery_level = $4, battery_level_read_date = $5 WHERE mac_address IN ($1, $2, $3)",
            [macAddress, secondFormatMacAddress, thirdFormatMacAddress, batteryLevel, timestamp]
          );
          console.log("Update battery level successfully");
        }
      }
    } catch (error) {
      console.error("Error while updating battery level ", error);
      throw error;
    }
  }
  if (!event.PayloadData) {
    return {
      statusCode: 400,
      body: "Invalid message!"
    };
  }
  const payloadData = convertBase64ToHex(event.PayloadData);
  if (payloadData.substring(0, 1) === "8") {
    const packageNumber = parseInt(payloadData.substring(1, 2));
    const data = [];
    if (packageNumber > 0 && packageNumber <= 15) {
      const chunkSize = 18;
      for (let i = 1; i <= packageNumber; i++) {
        const start = (i - 1) * chunkSize + 2;
        const chunk = payloadData.slice(start, start + chunkSize);
        if (chunk.length === 18) {
          const macAddress = chunk.slice(0, 12).toUpperCase();
          const batteryPercentage = convertHexToDecimal(chunk.slice(14, 16));
          if (batteryPercentage > 0 && batteryPercentage <= 100) {
            data.push([
              macAddress,
              batteryPercentage
            ]);
          }
        }
      }
      if (data.length === 0) {
        return {
          statusCode: 400,
          body: "Invalid payload!"
        };
      }
    } else {
      return {
        statusCode: 400,
        body: "Invalid package number!"
      };
    }
    await connectToDatabase();
    if (dbConnection === null) {
      return {
        statusCode: 500,
        body: "Could not connect to the database!"
      };
    }
    try {
      await updateData(data);
    } catch {
      if (dbConnection) {
        await dbConnection.end();
        dbConnection = null;
      }
      return {
        statusCode: 500,
        body: "Failed to update beacon's battery into database!"
      };
    }
    console.log("Proccess successfully!");
    return {
      statusCode: 200,
      body: "Proccess successfully!"
    };
  } else {
    return {
      statusCode: 400,
      body: "Not the Beacon forwarder payload!"
    };
  }
};
//# sourceMappingURL=index.mjs.map
